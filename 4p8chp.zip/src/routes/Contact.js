function Contact(){

  return(
    <>
      <h1>This is the contact page</h1>
    </>
  )

}

export default Contact;