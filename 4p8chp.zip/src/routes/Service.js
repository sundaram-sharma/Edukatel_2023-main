function Service(){

  return(
    <>
      <h1>This is the service page</h1>
    </>
  )

}

export default Service;